from multiprocessing import context
from django.shortcuts import render

# Create your views here.


def index(request):
    context = {
        'nama': 'Yoga',
        'nav': [
            ['/', 'Kembali ke Home'],
            ['/about/akun/', 'Account'],
            ['/about/blog/', 'Blog']
        ],
        'header': 'Tentang Kami',
    }
    return render(request, 'about/about.html', context)
