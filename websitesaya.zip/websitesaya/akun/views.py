from multiprocessing import context
from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.


def index(request):
    context = {
        'banner': 'akun\img\gambar_akun.jpg',
    }
    return render(request, 'akun/akun.html', context)


def register(request):
    context = {
        'banner': 'akun\img\gambar_akun.jpg',
    }
    return render(request, 'akun/register.html', context)
