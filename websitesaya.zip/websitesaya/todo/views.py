from multiprocessing import context
from django.shortcuts import render

# Create your views here.


def todo(request):
    context = {
        'header': 'ini todo',

    }
    return render(request, "todo/todo.html")
