from django.urls import path
from . import views
urlpatterns = [
    path('recent', views.recent, name='recent'),
    path('', views.index, name='index'),


]
