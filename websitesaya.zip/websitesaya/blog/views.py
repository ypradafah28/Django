from multiprocessing import context
from urllib import request
from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.


def index(request):
    context = {
        'nama': 'Yoga Pradafa Harahap',
        'banner': 'blog\img\gambar_blog.jpg',
        'nav': [
            ['/', 'Kembali ke Home'],
            ['/about/blog/recent', 'Go To Recent Pos']
        ],
        'header': 'Selamat datang di Blog saya'
    }
    return render(request, 'blog/blog.html', context)


def recent(request):
    return HttpResponse("<h1> Selamat Datang di recent pos </h1>")
